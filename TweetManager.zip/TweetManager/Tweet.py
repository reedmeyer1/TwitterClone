import time
class Tweet:
    def __init__(self):
        self.__author = str(input('What is your name? '))
        self.__text = str(input('What would you like to tweet? '))
        self.__age = time.strftime('%H %M %S')
    def get_author(self):
        return self.__author
    def get_text(self):
        return self.__text
    def get_age(self):
        return self.__age
