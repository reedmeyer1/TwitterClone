import Tweet
import pickle
import time
tweetHistory = {}
def recent():
    history = open('tweetHistory.dat', 'rb')
    for key, value in tweetHistory.items():
        simpleTime = value[1].strip("')")
        currTime = time.strftime('%H %M %S')
        oldTime = simpleTime.split(' ')
        newTime = currTime.split(' ')
        hours = int(newTime[0]) - int(oldTime[0])
        minute = int(newTime[1]) - int(oldTime[1])
        minutes = minute + 60 * hours
        second = int(newTime[2]) - int(oldTime[2])
        seconds = second + 60 * minutes
        content = value[0].strip("('")
        if seconds < 30:
            print("-", key, "--", content, "-- Just Posted -")
        elif seconds >= 30 and seconds < 900:
            print("-", key, "--", content, "-- Posted 30 seconds ago -")
        elif seconds >= 900 and seconds < 3600:
            print("-", key, "--", content, "-- Posted 15 minutes ago -")
        elif seconds >= 3600:
            print("-", key, "--", content, "-- Posted over an hour ago -")
    history.close()
    
def tweet():
    tweet = Tweet.Tweet()
    tweetHistory[tweet.get_author()] = tweet.get_text(), tweet.get_age()
    history = open('tweetHistory.dat', 'wb')
    pickle.dump(tweetHistory, history)
    history.close()     

def search():
    userInput = str(input('What would you like to search for? '))
    searchSuccess = False
    for key, value in tweetHistory.items():
        content = value[0].strip("('")
        testValue = userInput in content
        if testValue == True:
            print(key, ":", content)
            searchSuccess = True
            continue
        else:
            continue
    if searchSuccess == False:
        print("Phrase:", userInput, "not found")
def exitpro():
    print('Closing Program')   
    
def menu():
        try:
            print('Tweet Menu \n----------------')
            print('1. Make a Tweet')
            print('2. View Recent Tweets')
            print('3. Search Tweets')
            print('4. Quit')
            userInput = int(input('What would you like to do? '))
            if userInput == 1:
                print(' ')
                tweet()
                print(' ')
                menu()     
            elif userInput == 2:
                print(' ')
                recent()
                print(' ')
                menu()
            elif userInput == 3:
                print(' ')
                search()
                print(' ')
                menu()
            elif userInput == 4:
                print(' ')
                exitpro()
            else:
                print(' ')
                print('Please input a number between 1 and 4')
                print(' ')
                menu()
        except ValueError:
            print(' ')
            print('Please input a number between 1 and 4')
            print(' ')
            menu()
        else:
            print(' ')
menu()
